#include <streams.h>
#include "parser.h"
#include <malloc.h>
#include <math.h>

//=============================================================================
//=============================================================================

static const int ADTS_MAX_SIZE(9); 
static const int sample_rates[] = {96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000};

typedef struct {
	BYTE version;
	BYTE header_size;
    BYTE object_type;
	BYTE sr_idx;
    BYTE channels;
    int sampling_rate;
    int frames;
    int bitrate;
	double duration;
} AACInfo;

static HRESULT read_buffer_filestream(IAsyncReader *file, LONGLONG *pos, unsigned char *buffer, int length)
{
	HRESULT hr = file->SyncRead(*pos, length, buffer);
	*pos += length;
	return hr;
}

static HRESULT read_ADTS_header(IAsyncReader *file, AACInfo *info, unsigned long **seek_table, int *seek_table_len, int *tagsize)
{
	unsigned char buffer[ADTS_MAX_SIZE];
	int frames, framesinsec=0, t_framelength = 0, frame_length, ID;
	int second = 0;
	double frames_per_sec = 0;
	unsigned long *tmp_seek_table = NULL;

	/* Skip the tag, if it's there */
	LONGLONG pos(0);
	HRESULT hr = read_buffer_filestream(file, &pos, buffer, 10);
	if (hr != S_OK)
		return hr;
	if (memcmp(buffer, "ID3", 3) == 0)
	{
		/* high bit is not used */
		*tagsize = (buffer[6] << 21) | (buffer[7] << 14) | (buffer[8] <<  7) | (buffer[9] << 0);
		*tagsize += 10;
	}
	else
		*tagsize = 0;

	/* Get ADTS header data */
	/* Read all frames to ensure correct time and bitrate */
	pos = *tagsize;
	for (frames=0; /* */; frames++, framesinsec++)
	{
		// read the header
		hr = read_buffer_filestream(file, &pos, buffer, ADTS_MAX_SIZE);
		if (FAILED(hr))
			return hr;
		if (hr != S_OK)
			break; //no more data

		// check syncword
		if (!((buffer[0] == 0xFF)&&((buffer[1] & 0xF0) == 0xF0)))
			return E_FAIL;

		// fixed ADTS header is the same for every frame, so we read it only once
		if (!frames)
		{
			// parse the fixed ADTS header
			ID = buffer[1] & 0x08;
			info->version = (ID == 0) ? 4 : 2;
			info->header_size = (buffer[1] & 0x01) > 0 ? 7 : 9;
			info->object_type = (buffer[2]&0xC0)>>6;
			info->sr_idx = (buffer[2]&0x3C)>>2;
			info->channels = ((buffer[2]&0x01)<<2)|((buffer[3]&0xC0)>>6);

			frames_per_sec = sample_rates[info->sr_idx] / 1024.f;
		}

		// ...and the variable ADTS header. 
		// No longer any difference in position of frame_length between mpeg-4 and mpeg-2 headers.
		frame_length = ((((unsigned int)buffer[3] & 0x3)) << 11) | (((unsigned int)buffer[4]) << 3) | (buffer[5] >> 5);

		t_framelength += frame_length;

		if (seek_table_len)
		{
			if (frames == *seek_table_len)
			{
				*seek_table_len += 1024;
				*seek_table = (unsigned long *) realloc(*seek_table, (*seek_table_len) * sizeof(unsigned long));
			}
			(*seek_table)[frames] = DWORD(pos - ADTS_MAX_SIZE);
		}

		pos += frame_length - ADTS_MAX_SIZE;
	}

	info->sampling_rate = sample_rates[info->sr_idx];
	info->bitrate = (int)(((t_framelength / frames) * (info->sampling_rate/1024.0)) +0.5)*8;

	info->duration = frames / frames_per_sec;
	info->frames = frames;
	return S_OK;
}

//=============================================================================
//=============================================================================

// {3C78B8E2-6C4D-11d1-ADE2-0000F8754B98}
static const GUID CLSID_AACPARSER = {0x3c78b8e2, 0x6c4d, 0x11d1, { 0xae, 0xe2, 0x0, 0x0, 0xf7, 0x75, 0x4b, 0x98}};

// Be compatible with 3ivx
static const DWORD WAVE_FORMAT_AAC (0x000000FF);

// {000000FF-0000-0010-8000-00AA00389B71}
static const GUID MEDIASUBTYPE_AAC = {WAVE_FORMAT_AAC, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};

class CWavDestFilter : public CParserFilter
{
public:
	static CUnknown * __stdcall CreateInstance(LPUNKNOWN punk, HRESULT *pHr);

	CWavDestFilter(LPUNKNOWN pUnk, HRESULT *pHr);
	~CWavDestFilter();

	DECLARE_IUNKNOWN;

	HRESULT CheckInputType(const CMediaType* mtIn) ;
	HRESULT CheckTransform(const CMediaType *mtIn, const CMediaType *mtOut);
	HRESULT GetMediaType(int iPosition, CMediaType *pMediaType);

	HRESULT DecideBufferSize(IMemAllocator *pAlloc, ALLOCATOR_PROPERTIES *pProperties);

	HRESULT CompleteConnect(PIN_DIRECTION direction, IPin *pReceivePin) 
	{ 
		if (direction == PINDIR_INPUT)
		{
			IAsyncReader * pIAsyncReader(NULL);
			m_pInput->GetReader(&pIAsyncReader);
			LONGLONG llSizeAvailable;
			pIAsyncReader->Length(&m_llSize, &llSizeAvailable);
			pIAsyncReader->Release();

			HRESULT hr = read_ADTS_header(pIAsyncReader, &m_info, &m_seek_table, &m_seek_table_len, &m_tagsize);
			if (hr != S_OK)
				return hr;

			m_rtDuration = LONGLONG(m_info.duration * 1E7); // 100 nanosecond units!
			m_pOutput->SetDuration(m_rtDuration);
			
			Seek(0);
		}
		return S_OK; 
	}
	
	HRESULT FillSample(IAsyncReader* pReader, IMediaSample* pSample)
	{
		// allocate a suitably sized buffer
		LONG sample_max = pSample->GetSize();
		LONG buffer_max(sample_max);
		PBYTE buffer = (PBYTE)_alloca(buffer_max);

		// find how much data remains
		LONGLONG data_max(m_llSize - m_llCurrent);

		// get the sample (output) buffer
		PBYTE sampleBuffer(NULL);
		HRESULT hr = pSample->GetPointer(&sampleBuffer);
		if (FAILED(hr) || sampleBuffer == NULL)
			return E_FAIL;

		// read frames until the sample buffer is full or we run out of data
		int number_of_frames(0);
        int data_used(0);
        int sample_length(0);
		bool bEOF(false);
		for (;;)
		{
			// check we have enough data to read the header
			if (data_used + m_info.header_size > data_max)
			{
				bEOF = true;
				break;
			}

			// read the header
			if (m_info.header_size > buffer_max)
				return E_FAIL;
			hr = pReader->SyncRead(m_llCurrent + data_used, m_info.header_size, buffer);
			if (FAILED(hr))
				return hr;
			
			// check syncword
			if (!((buffer[0] == 0xFF)&&((buffer[1] & 0xF6) == 0xF0)))
				return E_FAIL;

			// find the framelength (includes the header)
			int frame_length(0);
			frame_length = ((((unsigned int)buffer[3] & 0x3)) << 11) | (((unsigned int)buffer[4]) << 3) | (buffer[5] >> 5);

			// the number of AAC blocks in this ADTS frame is 1 + extra_blocks
			BYTE extra_blocks = (buffer[6] & 0x03);
			
			// check we have enough data for the rest of the frame
			if (data_used + frame_length > data_max)
			{
				bEOF = true;
				break;
			}
			
			// read the rest of the frame
			if (frame_length > buffer_max)
				return E_FAIL;
			hr = pReader->SyncRead(m_llCurrent + data_used + m_info.header_size, frame_length - m_info.header_size, buffer + m_info.header_size);
			if (FAILED(hr))
				return hr;
	
			// check for the sample buffer being full
			if (sample_length + frame_length - m_info.header_size > sample_max)
				break;

			// copy the AAC part of the frame into the output buffer
			memcpy(sampleBuffer + sample_length, buffer + m_info.header_size, frame_length - m_info.header_size);

			// keep track of where we are
			number_of_frames += 1;
			data_used += frame_length;
			sample_length += frame_length - m_info.header_size;

			// If multiple blocks are put into the sample the CoreAAC Audio Decoder seems to play only the first  
			// and the 3ivx D4 Audio Decoder access violates. Hence jump out here after a single frame. 
			// Obvious problem if this frame contains more than one block.
			ASSERT(extra_blocks == 0);
			break; 
		}

		pSample->SetActualDataLength(sample_length);

		long lStopFrame = m_lCurrentFrame + number_of_frames;
		LONGLONG rtMediaStart = (m_lCurrentFrame * 1024 * UNITS) / m_info.sampling_rate;
		LONGLONG rtMediaStop  = (lStopFrame      * 1024 * UNITS) / m_info.sampling_rate;
		pSample->SetMediaTime(&rtMediaStart, &rtMediaStop);
		REFERENCE_TIME rtStart = rtMediaStart - m_rtStart;
		REFERENCE_TIME rtStop  = rtMediaStop  - m_rtStart;
		pSample->SetTime(&rtStart, &rtStop);

		m_lCurrentFrame = lStopFrame;
		m_llCurrent += data_used;
		return bEOF ? S_FALSE : S_OK;
	}

	// This has to set:
	// m_rtStart to the point the user has selected (not necessarily the start of a frame)
	// m_lCurrentFrame to the last frame that starts on or before m_rtStart
	// m_llCurrent to the start of m_lCurrentFrame
	HRESULT Seek(REFERENCE_TIME rtStart)
	{
		if (m_pInput == NULL)
			return E_UNEXPECTED;

		if (m_pInput->IsConnected() == FALSE)
			return E_UNEXPECTED;

		int AtStart = m_pInput->StartSeek();

		m_rtStart = rtStart;
		m_lCurrentFrame = long((m_info.frames * m_rtStart) / m_rtDuration);
		m_llCurrent = m_seek_table[m_lCurrentFrame];

		return m_pInput->FinishSeek(AtStart);
	}

private:

	void BuildWaveFormatEx(PWAVEFORMATEX * ppwfe, DWORD * pdwLength);
	void Init();
	LONG m_lCurrentFrame;
	REFERENCE_TIME m_rtStart;
	REFERENCE_TIME m_rtDuration;
	int m_tagsize;
	AACInfo m_info;
	DWORD * m_seek_table;
	int m_seek_table_len;
	LONGLONG m_llSize;
	LONGLONG m_llCurrent;
};

// ------------------------------------------------------------------------
// constructor
//
CWavDestFilter::CWavDestFilter(LPUNKNOWN pUnk, HRESULT *phr) :
	CParserFilter(NAME("aac_parser filter"), pUnk, CLSID_AACPARSER)
{
	Init();
}

// ------------------------------------------------------------------------
// destructor
//
CWavDestFilter::~CWavDestFilter()
{
}

void CWavDestFilter::Init()
{
	m_lCurrentFrame = 0;
	m_rtStart = 0;
	m_rtDuration = 0;
	m_tagsize = 0;
	//faadAACInfo m_info;
	m_seek_table = NULL;
	m_seek_table_len = 0;
	m_llSize = 0;
	m_llCurrent = 0;
}

CUnknown * __stdcall CWavDestFilter::CreateInstance(LPUNKNOWN pUnk, HRESULT * phr)
{
    return new CWavDestFilter(pUnk, phr);
}

//
// CWavDestFilter::CheckTransform
//
HRESULT CWavDestFilter::CheckTransform(const CMediaType *mtIn, const CMediaType *mtOut)
{
    HRESULT hr;
    if (FAILED(hr = CheckInputType(mtIn))) 
	{
		return hr;
    }
    return NOERROR;
} // CheckTransform

//
// CheckInputType
//
HRESULT CWavDestFilter::CheckInputType(const CMediaType* mtIn)
{
	if (IsEqualGUID(*mtIn->Type(), MEDIATYPE_Stream) && IsEqualGUID(*mtIn->Subtype(), MEDIASUBTYPE_MPEG1Audio))
		return S_OK;
	else
		return VFW_E_TYPE_NOT_ACCEPTED;
}

void CWavDestFilter::BuildWaveFormatEx(
	PWAVEFORMATEX * ppwfe ,
	DWORD * pdwLength     )
{
	WORD wExtra(2);
	WORD wLength = sizeof(WAVEFORMATEX) + wExtra;
	PWAVEFORMATEX p = PWAVEFORMATEX(malloc(wLength));

	p->wFormatTag = WAVE_FORMAT_AAC;
	p->nChannels = m_info.channels;
	p->nSamplesPerSec = m_info.sampling_rate;
	p->nBlockAlign = 4;//1;
	p->nAvgBytesPerSec = m_info.bitrate;
	p->wBitsPerSample = 16;
	p->cbSize = wExtra;
	PBYTE pExtra = (PBYTE)(p + 1);
	//The extra 2 bytes is a bitfield of info on the compression format:
	//5 bits objType, 4 bits freqIndex, 4 bits channels, 3 bits zero.
	//For example, if 
	//objType = 2 = 00010 (see "object types for AAC" in faad.h)
	//freqIndex = 3 = 0011 (zero based index into sample_rates[])
	//channels = 2 = 0010
	//zero = 0 = 000
	//=> 00010001 10010000 = 0x11, 0x90
	//pExtra[0] = 0x11;
	//pExtra[1] = 0x90;
	pExtra[0] = (m_info.object_type << 3) | (m_info.sr_idx >> 1);
	pExtra[1] = (m_info.sr_idx << 7) | (m_info.channels << 3);

	*pdwLength = wLength;
	*ppwfe = p;
}

//
// GetMediaType
//
HRESULT CWavDestFilter::GetMediaType(int iPosition, CMediaType *pMediaType)
{
	if (iPosition < 0)
		return E_INVALIDARG;

	if (iPosition > 0)
		return VFW_S_NO_MORE_ITEMS;

	PWAVEFORMATEX pwfe;
	DWORD dwLength;
	BuildWaveFormatEx(&pwfe, &dwLength);
	pMediaType->SetType(&MEDIATYPE_Audio);
	pMediaType->SetSubtype(&MEDIASUBTYPE_AAC);
	pMediaType->SetFormatType(&FORMAT_WaveFormatEx);
	pMediaType->SetFormat((BYTE *)pwfe, dwLength);
	::free(pwfe);

	return NOERROR;
}

//
// DecideBufferSize
//
HRESULT CWavDestFilter::DecideBufferSize(IMemAllocator *pAlloc,ALLOCATOR_PROPERTIES *pProperties)
{
	ASSERT(pProperties);

	pProperties->cbAlign = 1;
	pProperties->cbBuffer = 16 * 1024;
	pProperties->cbPrefix = 0;
	pProperties->cBuffers = 1;
if (pAlloc)
{
	// Ask the allocator to reserve us some sample memory, NOTE the function
	// can succeed (that is return NOERROR) but still not have allocated the
	// memory that we requested, so we must check we got whatever we wanted

	ALLOCATOR_PROPERTIES Actual;
	HRESULT hr = pAlloc->SetProperties(pProperties, &Actual);
	if (FAILED(hr))
		return hr;

	ASSERT( Actual.cBuffers == 1 );

	if (pProperties->cBuffers > Actual.cBuffers || pProperties->cbBuffer > Actual.cbBuffer)
	{
		return E_FAIL;
	}
}
	return NOERROR;
}

//=============================================================================
//=============================================================================

const AMOVIESETUP_MEDIATYPE sudIpPinTypes =
{ &MEDIATYPE_Stream     // clsMajorType
, &MEDIASUBTYPE_MPEG1Audio }; // clsMinorType

const AMOVIESETUP_MEDIATYPE sudOpPinTypes =
{ &MEDIATYPE_Audio     // clsMajorType
, &MEDIASUBTYPE_AAC }; // clsMinorType

const AMOVIESETUP_PIN sudPins [2] =
{ L"Input"           // strName
, FALSE              // bRendered
, FALSE              // bOutput
, FALSE              // bZero
, FALSE              // bMany
, &CLSID_NULL        // clsConnectsToFilter
, L""                // strConnectsToPin
, 1                  // nTypes
, &sudIpPinTypes     // lpTypes

, L"Output"          // strName
, FALSE              // bRendered
, TRUE               // bOutput
, FALSE              // bZero
, FALSE              // bMany
, &CLSID_NULL        // clsConnectsToFilter
, L""                // strConnectsToPin
, 1                  // nTypes
, &sudOpPinTypes };  // lpTypes

const AMOVIESETUP_FILTER sudWavDest =
{
    &CLSID_AACPARSER,         // clsID
    L"AAC Parser",            // strName
    MERIT_UNLIKELY,           // dwMerit
    2,                        // nPins
    sudPins                   // lpPin
};

CFactoryTemplate g_Templates[]= {
    {L"aac_parser", &CLSID_AACPARSER, CWavDestFilter::CreateInstance, NULL, &sudWavDest},
};
int g_cTemplates = sizeof(g_Templates) / sizeof(g_Templates[0]);;

//
// Filter registration functions
//
HRESULT __stdcall DllRegisterServer()
{
    return AMovieDllRegisterServer2(TRUE);
}

HRESULT __stdcall DllUnregisterServer()
{
    return AMovieDllRegisterServer2(FALSE);
}
extern "C" BOOL WINAPI DllEntryPoint(HINSTANCE, ULONG, LPVOID);

BOOL WINAPI DllMain(HINSTANCE hInstance, ULONG ulReason, LPVOID pv) 
{
	return DllEntryPoint(hInstance, ulReason, pv);
}
