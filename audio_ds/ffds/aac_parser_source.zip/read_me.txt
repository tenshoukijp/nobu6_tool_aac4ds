The code expects the base classes from the DirectShow samples in the DirectX 8.1 SDK to be at ..\..\BaseClasses:
DirectShow
	BaseClasses
	Filters
		aac_parser

