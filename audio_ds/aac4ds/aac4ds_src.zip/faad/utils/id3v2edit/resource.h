//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by id3v2edit.rc
//
#define PLUGIN_DLG                      101
#define IDD_CONFIG                      101
#define IDD_INFO                        102
#define IDD_EDITTEXTFRAME               103
#define IDD_ADDFRAME                    104
#define IDD_ADDSTANDARD                 105
#define IDR_MENU                        108
#define IDI_ICON                        109
#define IDD_ABOUT                       110
#define VARBITRATE_CHK                  1004
#define BUFFERING_SLIDER                1006
#define THREAD_PRIORITY_SLIDER          1007
#define IDC_ID3V2TAG                    1020
#define IDC_CLOSE                       1021
#define IDC_CANCEL                      1022
#define IDC_AUTOSAVE                    1022
#define IDC_HEADER                      1025
#define IDC_PROFILE                     1026
#define IDC_BITRATE                     1027
#define IDC_SAMPLERATE                  1028
#define IDC_CHANNELS                    1029
#define IDC_VERSION                     1030
#define IDC_ID3LIST                     1032
#define IDC_STATIC2                     1034
#define LOCAL_BUFFER_TXT                1035
#define STREAM_BUFFER_TXT               1036
#define IDC_CHECK1                      1037
#define IDC_SETGENERAL                  1037
#define OK_BTN                          1038
#define CANCEL_BTN                      1039
#define IDC_EDITTEXTFRAME               1040
#define IDC_FRAMETYPE                   1040
#define IDC_TEXTFRAMENAME               1041
#define IDC_COL0                        1041
#define IDC_DELFRAME                    1042
#define IDC_COL1                        1042
#define IDC_EDITFRAME                   1043
#define IDC_ADDFRAME                    1044
#define IDC_TRACK                       1045
#define IDC_ADDSTFRAMES                 1045
#define IDC_TITLE                       1046
#define IDC_FORMAT                      1046
#define IDC_NEXTFILE                    1046
#define IDC_ARTIST                      1047
#define IDC_BACKFILE                    1047
#define IDC_ALBUM                       1048
#define IDC_YEAR                        1049
#define IDC_COMMENT                     1050
#define IDC_FILENAME                    1050
#define IDC_COMPOSER                    1051
#define IDC_ORIGARTIST                  1052
#define IDC_COPYRIGHT                   1053
#define IDC_URL                         1054
#define IDC_ENCBY                       1055
#define IDC_GENRE                       1056
#define IDC_GENFRAMES                   1057
#define IDC_OPEN_FILE                   40003
#define IDC_SAVE_FILE                   40004
#define IDC_CLOSE_FILE                  40005
#define IDC_EXIT                        40006
#define IDC_ABOUT                       40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1058
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
