/*
* HDX4 AAC Decoder - Copyright (C) 2005 Jomigo GmbH
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//-------------------------------------------------------------------------------------------------------//
// AACDecoder.h : AAC DirectShow Decoder Filter
//-------------------------------------------------------------------------------------------------------//

#include "faad.h" // AAC-Decoder Library (FAAD1)

//-------------------------------------------------------------------------------------------------------//
// GUIDs
//-------------------------------------------------------------------------------------------------------//

// Filter GUID {3F89B91F-28A0-4974-93F1-ECB6AABD48DF}
DEFINE_GUID(CLSID_AACDECODER, 0x3f89b91f, 0x28a0, 0x4974, 0x93, 0xf1, 0xec, 0xb6, 0xaa, 0xbd, 0x48, 0xdf);

// ESL. Where does this one come from??? DEFINE_GUID(MEDIASUBTYPE_AAC, 0x0AAC, 0x000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71);

// GUID 000000FF-0000-0010-8000-00AA00389B71
DEFINE_GUID(MEDIASUBTYPE_AAC, 0x000000FF, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71);

// GUID 4134504D-0000-0010-8000-00AA00389B71
DEFINE_GUID(MEDIASUBTYPE_MP4A, 0x4134504D, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71);

//-------------------------------------------------------------------------------------------------------//
// FilterClass: see DirectX SDK -> DirectShow -> Using DirectShow -> Writing DirectShow (Transform) Filters
//
// DirectShow Filter Documentation:
// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/directshow/htm/writingdirectshowfilters.asp
//
// Transform Filter Documentation:
// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/directshow/htm/writingtransformfilters.asp
//
// DirectShow-Samples can be downloaded from:
// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/directshow/htm/sampledirectshowfilters.asp
//-------------------------------------------------------------------------------------------------------//

class CAACDecoder : public CTransformFilter
{
public :

	//----------------------------------------------------------------------------------------------------//
	// COM-Methodes: DirectX SDK -> DirectShow and COM
	//
	// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/directshow/htm/usingcunknown.asp)
	//----------------------------------------------------------------------------------------------------//

	DECLARE_IUNKNOWN
	STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void **ppv); 
	static CUnknown * WINAPI CreateInstance(LPUNKNOWN punk, HRESULT *phr);

	//----------------------------------------------------------------------------------------------------//
	// TransformFilter-Methodes: DirectX SDK -> CTransformFilter Class
	//
	// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/directshow/htm/ctransformfilterclass.asp)
	//----------------------------------------------------------------------------------------------------//

	HRESULT CheckInputType(const CMediaType *pmtIn);
	HRESULT CheckTransform(const CMediaType *pmtIn, const CMediaType *pmtOut);
	HRESULT DecideBufferSize(IMemAllocator *pAllocator, ALLOCATOR_PROPERTIES *pProperties);
	HRESULT GetMediaType(int iPosition, CMediaType *pmtOut);
	HRESULT Transform(IMediaSample *pIn, IMediaSample *pOut);

private:

	//----------------------------------------------------------------------------------------------------//
	// faad1 (faad_src_20020104.zip) source code and Documentation can be downloaded from:
	//
	// http://sourceforge.net/project/showfiles.php?group_id=704&package_id=10774&release_id=164018
	//----------------------------------------------------------------------------------------------------//

	faacDecHandle  m_hDecoder;			// faad1-Decoder-Handle (see ..\faad_src_20020104\docs\libfaad.pdf)
	unsigned char* m_pbESConfiguration;	// ElementaryStream-Configuration
	int			   m_nESConfigSize;		// ElementaryStream-Configuration-Size in bytes

	int m_nChannels;			// Audio Channels
	int m_nSamplesPerSec;		// Samples per Sec.
	int m_nBitsPerSample;		// Bits per Sample

	BYTE* m_pBuffer;			// Sample Buffer
	bool  MixDown;				// MultiChannel MixDown

	CAACDecoder(LPUNKNOWN lpunk, HRESULT *phr);
	~CAACDecoder(void);
};

//-------------------------------------------------------------------------------------------------------//