Installation Notes
==================
+ Use the register_aac4ds_release.bat to register the 2 filters required for DirectShow. Please note that on Vista you need to run this command from an *Administrator* cmd.exe window (i.e. even if you run from an account with Admin privileges you will need to select "Run as Administrator" when starting cmd.exe, also note that running the batch file with "Run as Administrator" will not work unless you edit the file and set the paths to be absolute).
+ Likewise use unregister_aac4ds_release.bat to uninstall.

Please go to http://sourceforge.net/projects/aac4ds to post all questions, issues, etc... 


3rd party packages
==================
+ DirectShow-AAC-DecoderWrapper code obtained from http://sourceforge.net/project/showfiles.php?group_id=134220&package_id=153232&release_id=331279
+ FAAD (version 1) from http://sourceforge.net/project/showfiles.php?group_id=704
+ Microsoft SDK Sample BaseClass for DirectShow from the Vista SDK
+ GDCL DirectShow Mpeg-4 Filters March 2007 release from muxer/demuxer from http://www.gdcl.co.uk/mpeg4/index.htm

License
=======
For 3rd party packages please refer to their corresponding licenses. All of my changes or additions not covered under the 3rd party licenses are licensed under LPGL.
