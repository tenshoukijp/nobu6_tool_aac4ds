//
// ElemType.h: implementations of elementary stream type classes.
//
// Media type and other format-specific data that depends
// on the format of the contained elementary streams.
//
// Geraint Davies, April 2004
//
// Copyright (c) GDCL 2004-6. All Rights Reserved. 
// You are free to re-use this as the basis for your own filter development,
// provided you retain this copyright notice in the source.
// http://www.gdcl.co.uk
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "mpeg4.h"
#include "ElemType.h"
#include <dvdmedia.h>

// ----- format-specific handlers -------------------

// default no-translation

class NoChangeHandler : public FormatHandler
{
public:
    long BufferSize(long MaxSize);
    void StartStream();
    long PrepareOutput(IMediaSample* pSample, Movie* pMovie, LONGLONG llPos, long cBytes);
};

long 
NoChangeHandler::BufferSize(long MaxSize)
{
    return MaxSize;
}

void 
NoChangeHandler::StartStream()
{
}

long 
NoChangeHandler::PrepareOutput(IMediaSample* pSample, Movie* pMovie, LONGLONG llPos, long cBytes)
{
    BYTE* pBuffer;
    pSample->GetPointer(&pBuffer);

    if (pMovie->ReadAbsolute(llPos, pBuffer, cBytes) == S_OK)
    {
        return cBytes;
    }
    return 0;
}

// for CoreAAC, minimum buffer size is 8192 bytes.
class CoreAACHandler : public NoChangeHandler
{
public:
    long BufferSize(long MaxSize)
    {
        if (MaxSize < 8192)
        {
            MaxSize = 8192;
        }
        return MaxSize;
    }
};

// for DivX, need to prepend data to the first buffer
// from the media type
class DivxHandler : public NoChangeHandler
{
public:
    DivxHandler(const BYTE* pDSI, long cDSI);
    long BufferSize(long MaxSize);
    void StartStream();
    long PrepareOutput(IMediaSample* pSample, Movie* pMovie, LONGLONG llPos, long cBytes);
private:
    smart_array<BYTE> m_pPrepend;
    long m_cBytes;
    bool m_bFirst;
};

DivxHandler::DivxHandler(const BYTE* pDSI, long cDSI)
{
    // The divx codec requires the stream to start with a VOL
    // header from the DecSpecificInfo. We search for
    // a VOL start code in the form 0x0000012x.
    while (cDSI > 4)
    {
        if ((pDSI[0] == 0) &&
            (pDSI[1] == 0) &&
            (pDSI[2] == 1) &&
            ((pDSI[3] & 0xF0) == 0x20))
        {
            m_cBytes = cDSI;
            m_pPrepend = new BYTE[m_cBytes];
            CopyMemory(m_pPrepend, pDSI,  m_cBytes);
            break;
        }
        pDSI++;
        cDSI--;
    }
}

long 
DivxHandler::BufferSize(long MaxSize)
{
    // we need to prepend the media type data
    // to the first sample, and with seeking, we don't know which
    // that will be.
    return MaxSize + m_cBytes; 
}

void 
DivxHandler::StartStream()
{
    m_bFirst = true;
}

long 
DivxHandler::PrepareOutput(IMediaSample* pSample, Movie* pMovie, LONGLONG llPos, long cBytes)
{
    if (m_bFirst)
    {
        m_bFirst = false;

        if (pSample->GetSize() < (cBytes + m_cBytes))
        {
            return 0;
        }

        BYTE* pBuffer;
        pSample->GetPointer(&pBuffer);

        // stuff the VOL header at the start of the stream
        CopyMemory(pBuffer,  m_pPrepend,  m_cBytes);
        pBuffer += m_cBytes;
        if (pMovie->ReadAbsolute(llPos, pBuffer, cBytes) != S_OK)
        {
            return 0;
        }
        return m_cBytes + cBytes;
            
    } else {
        return NoChangeHandler::PrepareOutput(pSample, pMovie, llPos, cBytes);
    }
}


// -----------------------------------------------------

ElementaryType::ElementaryType()
: m_cDecoderSpecific(0),
  m_tFrame(0),
  m_pHandler(NULL)
{
}

ElementaryType::~ElementaryType()
{
    delete m_pHandler;
}


bool 
ElementaryType::Parse(REFERENCE_TIME tFrame, Atom* patm)
{
    m_tFrame = tFrame;

    // the ESD atom is at the end of a type-specific
    // structure.
    AtomCache pSD(patm);
    long cOffset;
	bool bDescriptor = true;
    if (patm->Type() == DWORD('mp4v'))
    {
        m_type = Video_Mpeg4;
        m_cx = (pSD[24] << 8) + pSD[25];
        m_cy = (pSD[26] << 8) + pSD[27];
        cOffset = 78;
    } else if (patm->Type() == DWORD('jvt1')) 
    {
		// this is an older format that I think is not in use
        m_type = Video_H264;
        m_cx = (pSD[24] << 8) + pSD[25];
        m_cy = (pSD[26] << 8) + pSD[27];
        cOffset = 78;
    } else if (patm->Type() == DWORD('avc1'))
	{
		// this is 14496-15: there is no descriptor in this case
        m_type = Video_H264;
        m_cx = (pSD[24] << 8) + pSD[25];
        m_cy = (pSD[26] << 8) + pSD[27];
		cOffset = 78;
		bDescriptor = false;
	}else if (patm->Type() == DWORD('mp4a'))
    {
        m_type = Audio_AAC;
        cOffset = 28;
    } else if ((patm->Type() == DWORD('lpcm')) ||
               (patm->Type() == DWORD('alaw')) ||
               (patm->Type() == DWORD('ulaw')))
    {
        m_type = Audio_WAVEFORMATEX;
        cOffset = 28;
    } else {
        return false;
    }

    patm->ScanChildrenAt(cOffset);
    Atom* patmESD = patm->Child(0);
    if (!patmESD)
    {
        return false;
    }
    
    AtomCache pESD(patmESD);
    long cPayload = long(patmESD->Length() - patmESD->HeaderSize());
	if ((m_type == Video_H264) && !bDescriptor)
	{
		// iso 14496-15
		if (patmESD->Type() != DWORD('avcC'))
		{
			return false;
		}
		// store the whole payload as decoder specific
		m_cDecoderSpecific = cPayload;
		m_pDecoderSpecific = new BYTE[cPayload];
		CopyMemory(m_pDecoderSpecific,  pESD,  m_cDecoderSpecific);

	} else
	{
		if (pESD[0] != 0)
		{
			return false;   // only version 0 is speced
		}

		// parse the ES_Descriptor to get the decoder info
		Descriptor ESDescr;
		if (!ESDescr.Parse(pESD+4, cPayload-4) || (ESDescr.Type() != Descriptor::ES_DescrTag))
		{
			return false;
		}
		cOffset = 3;
		BYTE flags = ESDescr.Start()[2];
		if (flags & 0x80)
		{
			cOffset += 2;   // depends-on stream
		}
		if (flags & 0x40)
		{
			// URL string -- count of chars precedes string
			cOffset += ESDescr.Start()[cOffset] + 1;
		}
		if (flags & 0x20)
		{
			cOffset += 2;   // OCR id
		}
		Descriptor dscDecoderConfig;
		if (!ESDescr.DescriptorAt(cOffset, dscDecoderConfig))
		{
			return false;
		}
		Descriptor dscSpecific;
		if (!dscDecoderConfig.DescriptorAt(13, dscSpecific))
		{
			return false;
		}

		// store decoder-specific info
		m_cDecoderSpecific = dscSpecific.Length();
		m_pDecoderSpecific = new BYTE[dscSpecific.Length()];
		CopyMemory(m_pDecoderSpecific,  dscSpecific.Start(),  m_cDecoderSpecific);
	}
    return true;
}

bool 
ElementaryType::IsVideo()
{
    return (m_type == Video_H264) || (m_type == Video_Mpeg4);
}
    
bool 
ElementaryType::SetType(const CMediaType* pmt)
{
    if (m_mtChosen != *pmt)
    {
        delete m_pHandler;
        m_pHandler = NULL;
        m_mtChosen = *pmt;
    
        int idx = 0;
        CMediaType mtCompare;
        while (GetType(&mtCompare, idx))
        {
            if (mtCompare == *pmt)
            {
                // handler based on m_type and idx
                if (m_type == Audio_AAC)
                {
                    m_pHandler = new CoreAACHandler();
                } else if ((m_type == Video_Mpeg4) && (idx == 0))
                {
                    m_pHandler = new DivxHandler(m_pDecoderSpecific, m_cDecoderSpecific);
                } else {
                    m_pHandler = new NoChangeHandler();
                }
                return true;
            }
    
            idx++;
        }
        return false;
    }

    return true;
}

bool 
ElementaryType::GetType(CMediaType* pmt, int nType)
{
    // !! enable more type choices (eg dicas instead of divx for mpeg4)

    switch (m_type)
    {
    case Video_H264:
        if (nType == 0)
        {
            return GetType_H264(pmt);
        }
        break;

    case Video_Mpeg4:
        if (nType == 0)
        {
            return GetType_Mpeg4V(pmt);
        }
        // !! dicas 
        break;

    case Audio_AAC:
        if (nType == 0)
        {
            return GetType_AAC(pmt);
        }
        break;
    case Audio_WAVEFORMATEX:
        if (nType == 0)
        {
            return GetType_WAVEFORMATEX(pmt);
        }
        break;
    }

    return false;
}

bool
ElementaryType::GetType_H264(CMediaType* pmt)
{
    pmt->InitMediaType();
    pmt->SetType(&MEDIATYPE_Video);
    pmt->SetSubtype(&__uuidof(MEDIASUBTYPE_H264_MP4_Stream));
    pmt->SetFormatType(&FORMAT_MPEG2Video);

	// following the Nero/Elecard standard, we use an mpeg2videoinfo block
	// with dwFlags for nr of bytes in length field, and param sets in 
	// sequence header (allows 1 DWORD already -- extend this).

	const BYTE* pconfig = m_pDecoderSpecific;
	// count param set bytes (including 2-byte length)
	int cParams = 0;
	int cSeq = pconfig[5] & 0x1f;
	const BYTE* p = &pconfig[6];
	for (int i = 0; i < cSeq; i++)
	{
		int c = 2 + (p[0] << 8) + p[1];
		cParams += c;
		p += c;
	}
	int cPPS = *p++;
	for (int i = 0; i < cPPS; i++)
	{
		int c = 2 + (p[0] << 8) + p[1];
		cParams += c;
		p += c;
	}


	int cFormat = sizeof(MPEG2VIDEOINFO) + cParams - sizeof(DWORD);
    MPEG2VIDEOINFO* pVI = (MPEG2VIDEOINFO*)pmt->AllocFormatBuffer(cFormat);
    ZeroMemory(pVI, cFormat);
    pVI->hdr.bmiHeader.biWidth = m_cx;
    pVI->hdr.bmiHeader.biHeight = m_cy;
    pVI->hdr.AvgTimePerFrame = m_tFrame;

	pVI->dwProfile = pconfig[1];
	pVI->dwLevel = pconfig[3];

	// nr of bytes used in length field, for length-preceded NALU format.
	pVI->dwFlags = (pconfig[4] & 3) + 1;

	pVI->cbSequenceHeader = cParams;
	// copy all param sets
	cSeq = pconfig[5] & 0x1f;
	p = &pconfig[6];
	BYTE* pDest = (BYTE*) &pVI->dwSequenceHeader;
	for (int i = 0; i < cSeq; i++)
	{
		int c = 2 + (p[0] << 8) + p[1];
		CopyMemory(pDest, p, c);
		pDest += c;
		p += c;
	}
	cPPS = *p++;
	for (int i = 0; i < cPPS; i++)
	{
		int c = 2 + (p[0] << 8) + p[1];
		CopyMemory(pDest, p, c);
		pDest += c;
		p += c;
	}

    return true;
}

bool
ElementaryType::GetType_Mpeg4V(CMediaType* pmt)
{
    const DWORD DIVXFOURCC = DWORD('XVID');

    // for standard mpeg-4 video, we set the media type
    // up for the DivX decoder
    pmt->InitMediaType();
    pmt->SetType(&MEDIATYPE_Video);
    FOURCCMap divx(DIVXFOURCC);
    pmt->SetSubtype(&divx);
    pmt->SetFormatType(&FORMAT_VideoInfo);
    VIDEOINFOHEADER* pVI = (VIDEOINFOHEADER*)pmt->AllocFormatBuffer(sizeof(VIDEOINFOHEADER) + m_cDecoderSpecific);
    ZeroMemory(pVI, sizeof(VIDEOINFOHEADER));
    pVI->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    pVI->bmiHeader.biPlanes = 1;
    pVI->bmiHeader.biBitCount = 24;
    pVI->bmiHeader.biWidth = m_cx;
    pVI->bmiHeader.biHeight = m_cy;
    pVI->bmiHeader.biSizeImage = DIBSIZE(pVI->bmiHeader);
    pVI->bmiHeader.biCompression = DIVXFOURCC;
    pVI->AvgTimePerFrame = m_tFrame;

    BYTE* pDecSpecific = (BYTE*)(pVI+1);
    CopyMemory(pDecSpecific, m_pDecoderSpecific,  m_cDecoderSpecific);

    return true;
}

// static
const int ElementaryType::SamplingFrequencies[] = 
{
    96000,
    88200,
    64000,
    48000,
    44100,
    32000,
    24000,
    22050,
    16000,
    12000,
    11025,
    8000,
    7350,
    0,
    0,
    0,
};

bool
ElementaryType::GetType_AAC(CMediaType* pmt)
{
    // set for Free AAC Decoder faad

    const int WAVE_FORMAT_AAC = 0x00ff;

    pmt->InitMediaType();
    pmt->SetType(&MEDIATYPE_Audio);
    FOURCCMap faad(WAVE_FORMAT_AAC);
    pmt->SetSubtype(&faad);
    pmt->SetFormatType(&FORMAT_WaveFormatEx);
    WAVEFORMATEX* pwfx = (WAVEFORMATEX*)pmt->AllocFormatBuffer(sizeof(WAVEFORMATEX) + m_cDecoderSpecific);
    ZeroMemory(pwfx,  sizeof(WAVEFORMATEX));
    pwfx->cbSize = WORD(m_cDecoderSpecific);
    CopyMemory((pwfx+1),  m_pDecoderSpecific,  m_cDecoderSpecific);

    // parse decoder-specific info to get rate/channels
    long samplerate = ((m_pDecoderSpecific[0] & 0x7) << 1) + ((m_pDecoderSpecific[1] & 0x80) >> 7);
    pwfx->nSamplesPerSec = SamplingFrequencies[samplerate];
    pwfx->nBlockAlign = 1;
    pwfx->wBitsPerSample = 16;
    pwfx->wFormatTag = WAVE_FORMAT_AAC;
    pwfx->nChannels = (m_pDecoderSpecific[1] & 0x78) >> 3;
    
    return true;
}

bool
ElementaryType::GetType_WAVEFORMATEX(CMediaType* pmt)
{
    // common to standard audio types that have known atoms
    // in the mpeg-4 file format

    // the dec-specific info is a waveformatex
    WAVEFORMATEX* pwfx = (WAVEFORMATEX*)(BYTE*)m_pDecoderSpecific;
    if ((m_cDecoderSpecific < sizeof(WAVEFORMATEX)) ||
        (m_cDecoderSpecific < int(sizeof(WAVEFORMATEX) + pwfx->cbSize)))
    {
        return false;
    }

    pmt->InitMediaType();
    pmt->SetType(&MEDIATYPE_Audio);
    FOURCCMap subtype(pwfx->wFormatTag);
    pmt->SetSubtype(&subtype);
    pmt->SetFormatType(&FORMAT_WaveFormatEx);

    int cLen = pwfx->cbSize + sizeof(WAVEFORMATEX);
    WAVEFORMATEX* pwfxMT = (WAVEFORMATEX*)pmt->AllocFormatBuffer(cLen);
    CopyMemory(pwfxMT, pwfx, cLen);

    return true;
}

// --- descriptor parsing ----------------------
bool 
Descriptor::Parse(const BYTE* pBuffer, long cBytes)
{
    m_pBuffer = pBuffer;
    m_type = (eType)pBuffer[0];
    long idx = 1;
    m_cBytes = 0;
    do {
        m_cBytes = (m_cBytes << 7) + (pBuffer[idx] & 0x7f);
    } while ((idx < cBytes) && (pBuffer[idx++] & 0x80));

    m_cHdr = idx;
    if ((m_cHdr + m_cBytes) > cBytes)
    {
        m_cHdr = m_cBytes = 0;
        return false;
    }
    return true;
}

    
bool 
Descriptor::DescriptorAt(long cOffset, Descriptor& desc)
{
    return desc.Parse(Start() + cOffset, Length() - cOffset); 
}



