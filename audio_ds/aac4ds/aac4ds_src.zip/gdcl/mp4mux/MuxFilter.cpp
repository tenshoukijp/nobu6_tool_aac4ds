//
// MuxFilter.cpp
//
// Implementation of classes for DirectShow MPEG-4 Multiplexor filter
//
// Geraint Davies, May 2004
//
// Copyright (c) GDCL 2004-6. All Rights Reserved. 
// You are free to re-use this as the basis for your own filter development,
// provided you retain this copyright notice in the source.
// http://www.gdcl.co.uk
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MuxFilter.h"
#include <sstream>

// --- registration tables ----------------

// filter registration -- these are the types that our
// pins accept and produce
const AMOVIESETUP_MEDIATYPE 
Mpeg4Mux::m_sudType[] = 
{
    {
        &MEDIATYPE_Video,
        &MEDIASUBTYPE_NULL      // wild card
    },
    {
        &MEDIATYPE_Audio,
        &MEDIASUBTYPE_NULL
    },
    {
        &MEDIATYPE_Stream,
        &MEDIASUBTYPE_NULL,
    },
};

// registration of our pins for auto connect and render operations
const AMOVIESETUP_PIN 
Mpeg4Mux::m_sudPin[] = 
{
    {
        L"Video",           // pin name
        FALSE,              // is rendered?    
        FALSE,              // is output?
        FALSE,              // zero instances allowed?
        FALSE,              // many instances allowed?
        &CLSID_NULL,        // connects to filter (for bridge pins)
        NULL,               // connects to pin (for bridge pins)
        1,                  // count of registered media types
        &m_sudType[0]       // list of registered media types    
    },
    {
        L"Audio",           // pin name
        FALSE,              // is rendered?    
        FALSE,              // is output?
        FALSE,              // zero instances allowed?
        FALSE,              // many instances allowed?
        &CLSID_NULL,        // connects to filter (for bridge pins)
        NULL,               // connects to pin (for bridge pins)
        1,                  // count of registered media types
        &m_sudType[1]       // list of registered media types    
    },
    {
        L"Output",          // pin name
        FALSE,              // is rendered?    
        TRUE,               // is output?
        FALSE,              // zero instances allowed?
        FALSE,              // many instances allowed?
        &CLSID_NULL,        // connects to filter (for bridge pins)
        NULL,               // connects to pin (for bridge pins)
        1,                  // count of registered media types
        &m_sudType[2]       // list of registered media types    
    },
};

// filter registration information. 
const AMOVIESETUP_FILTER 
Mpeg4Mux::m_sudFilter = 
{
    &__uuidof(Mpeg4Mux),    // filter clsid
    L"GDCL Mpeg-4 Multiplexor",        // filter name
    MERIT_DO_NOT_USE,       // ie explicit insertion only
    3,                      // count of registered pins
    m_sudPin                // list of pins to register
};

// ---- construction/destruction and COM support -------------

// the class factory calls this to create the filter
//static 
CUnknown* WINAPI 
Mpeg4Mux::CreateInstance(LPUNKNOWN pUnk, HRESULT* phr)
{
    return new Mpeg4Mux(pUnk, phr);
}


Mpeg4Mux::Mpeg4Mux(LPUNKNOWN pUnk, HRESULT* phr)
: CBaseFilter(NAME("Mpeg4Mux"), pUnk, &m_csFilter, *m_sudFilter.clsID),
  m_tWritten(0)
{
    // create output pin and one free input
    m_pOutput = new MuxOutput(this, &m_csFilter, phr);
    CreateInput();
}

Mpeg4Mux::~Mpeg4Mux()
{
    delete m_pOutput;
    for (UINT i = 0; i < m_pInputs.size(); i++)
    {
        m_pInputs[i]->Release();
    }
}


STDMETHODIMP 
Mpeg4Mux::NonDelegatingQueryInterface(REFIID iid, void** ppv)
{
    if (iid == IID_IMediaSeeking)
    {
        return GetInterface((IMediaSeeking*) this, ppv);
    }
    return CBaseFilter::NonDelegatingQueryInterface(iid, ppv);
}

int 
Mpeg4Mux::GetPinCount()
{
    // one output, plus variable set of inputs
    return m_pInputs.size() + 1;
}

CBasePin *
Mpeg4Mux::GetPin(int n)
{
    // list all inputs first, then one output

    if (n == (int)m_pInputs.size())
    {
        return m_pOutput;
    } else if (n < (int)m_pInputs.size())
    {
        return m_pInputs[n];
    }
    return NULL;
}

void
Mpeg4Mux::CreateInput()
{
	ostringstream strm;
	strm << "Input " << m_pInputs.size() + 1;
	_bstr_t str = strm.str().c_str();

	HRESULT hr = S_OK;
    MuxInput* pPin = new MuxInput(this, &m_csFilter, &hr, str, m_pInputs.size());
    pPin->AddRef();
    m_pInputs.push_back(pPin);

    // ensure enumerator is refreshed
    IncrementPinVersion();
}

void 
Mpeg4Mux::OnDisconnect(int index)
{
    // if index is the last but one, and
    // the last one is still unconnected, then
    // remove the last one
    if ((index == (int)(m_pInputs.size() - 2)) &&
        (!m_pInputs[m_pInputs.size()-1]->IsConnected()))
    {
        m_pInputs[m_pInputs.size()-1]->Release();
        m_pInputs.pop_back();

        // refresh enumerator
        IncrementPinVersion();
    }
}

void 
Mpeg4Mux::OnConnect(int index)
{
    // if this is the last one, make a new one
    if (index == (int)(m_pInputs.size()-1))
    {
        CreateInput();
    }
}

bool 
Mpeg4Mux::CanReceive(const CMediaType* pmt)
{
    return TypeHandler::CanSupport(pmt);
}

TrackWriter* 
Mpeg4Mux::MakeTrack(int index, const CMediaType* pmt)
{
    CAutoLock lock(&m_csTracks);
    UNREFERENCED_PARAMETER(index);
    return m_pMovie->MakeTrack(pmt);
}

void 
Mpeg4Mux::OnEOS()
{
    // all tracks are now written
    m_pOutput->DeliverEndOfStream();
}

STDMETHODIMP 
Mpeg4Mux::Stop()
{
    HRESULT hr = S_OK;
    if (m_State != State_Stopped)
    {
        // stop queue-writing before
        // pins empty queues
        if (m_pMovie)
        {
            m_pMovie->Stop();
        }

        // stop all input pins
        hr = CBaseFilter::Stop();

        if (m_pMovie)
        {
            // all data has been written -- now switch to metadata output
            m_pOutput->UseIStream();

            // write all metadata
            hr = m_pMovie->Close(&m_tWritten);
            m_pMovie = NULL;

            // fill remaining file space
            m_pOutput->FillSpace();
        }
    }
    return hr;
}
    

STDMETHODIMP 
Mpeg4Mux::Pause()
{
    if (m_State == State_Stopped)
    {
        m_pOutput->Reset();
        m_pMovie = new MovieWriter(m_pOutput);
    }
    return CBaseFilter::Pause();
}

// ------- input pin -------------------------------------------------------

MuxInput::MuxInput(Mpeg4Mux* pFilter, CCritSec* pLock, HRESULT* phr, LPCWSTR pName, int index)
: m_pMux(pFilter),
  m_index(index),
  m_pTrack(NULL),
  CBaseInputPin(NAME("MuxInput"), pFilter, pLock, phr, pName)
{
}

HRESULT 
MuxInput::CheckMediaType(const CMediaType* pmt)
{
    if (m_pMux->CanReceive(pmt))
    {
        return S_OK;
    }
    return VFW_E_TYPE_NOT_ACCEPTED;
}

HRESULT 
MuxInput::GetMediaType(int iPosition, CMediaType* pmt)
{
    UNREFERENCED_PARAMETER(iPosition);
    UNREFERENCED_PARAMETER(pmt);
    return VFW_S_NO_MORE_ITEMS;
}

STDMETHODIMP 
MuxInput::Receive(IMediaSample* pSample)
{
    HRESULT hr = CBaseInputPin::Receive(pSample);
    if (hr != S_OK)
    {
        return hr;
    }
    if (!m_pTrack)
    {
        return E_FAIL;
    }
    return m_pTrack->Add(pSample);
}

STDMETHODIMP 
MuxInput::EndOfStream()
{
    if ((m_pTrack != NULL) && (m_pTrack->OnEOS()))
    {
        // we are the last -- can forward now
        m_pMux->OnEOS();
    }
    return S_OK;
}

STDMETHODIMP 
MuxInput::BeginFlush()
{
    // ensure no more data accepted, and queued
    // data is discarded, so no threads are blocking
    if (m_pTrack)
    {
        m_pTrack->Stop();
    }
    return S_OK;
}

STDMETHODIMP 
MuxInput::EndFlush()
{
    // we don't re-enable writing -- we support only
    // one contiguous sequence in a file.
    return S_OK;
}

HRESULT 
MuxInput::Active()
{
    HRESULT hr = CBaseInputPin::Active();
    if (SUCCEEDED(hr))
    {
        m_pTrack = m_pMux->MakeTrack(m_index, &m_mt);
    }
    return hr;
}

HRESULT 
MuxInput::Inactive()
{
    // ensure that there are no more writes and no blocking threads
    m_pTrack->Stop();
    m_pTrack = NULL;
    return CBaseInputPin::Inactive();
}

HRESULT 
MuxInput::BreakConnect()
{
    HRESULT hr = CBaseInputPin::BreakConnect();
    m_pMux->OnDisconnect(m_index);
    return hr;
}


HRESULT 
MuxInput::CompleteConnect(IPin *pReceivePin)
{
    HRESULT hr = CBaseInputPin::CompleteConnect(pReceivePin);
    if (SUCCEEDED(hr))
    {
        m_pMux->OnConnect(m_index);
    }
    return hr;
}

STDMETHODIMP 
MuxInput::GetAllocator(IMemAllocator** ppAllocator)
{
    CAutoLock lock(m_pLock);

    HRESULT hr = S_OK;
    MuxAllocator* pAlloc = new MuxAllocator(NULL, &hr, &m_mt);
    if (!pAlloc)
    {
        return E_OUTOFMEMORY;
    }
    pAlloc->QueryInterface(IID_IMemAllocator, (void**)&m_pAllocator);
    return pAlloc->QueryInterface(IID_IMemAllocator, (void**)ppAllocator);
}

MuxAllocator::MuxAllocator(LPUNKNOWN pUnk, HRESULT* phr, const CMediaType* pmt)
: CMemAllocator(NAME("MuxAllocator"), pUnk, phr),
  m_mt(*pmt)
{
}

// we override this just to increase the requested buffer count
STDMETHODIMP 
MuxAllocator::SetProperties(
        ALLOCATOR_PROPERTIES* pRequest,
        ALLOCATOR_PROPERTIES* pActual)
{
    // !! base buffer count on media type size?

    ALLOCATOR_PROPERTIES prop = *pRequest;
    prop.cBuffers = 100;
    return CMemAllocator::SetProperties(&prop, pActual);
}

// --- output --------------------------------------------------------

MuxOutput::MuxOutput(Mpeg4Mux* pFilter, CCritSec* pLock, HRESULT* phr)
: m_pMux(pFilter),
  m_llBytes(0),
  m_bUseIStream(false),
  CBaseOutputPin(NAME("MuxOutput"), pFilter, pLock, phr, L"Output")
{
}

// CBaseOutputPin overrides
HRESULT 
MuxOutput::CheckMediaType(const CMediaType* pmt)
{
    if (*pmt->Type() == MEDIATYPE_Stream)
    {
        return S_OK;
    }
    return VFW_E_TYPE_NOT_ACCEPTED;
}

HRESULT 
MuxOutput::GetMediaType(int iPosition, CMediaType* pmt)
{
    if (iPosition != 0)
    {
        return VFW_S_NO_MORE_ITEMS;
    }
    pmt->InitMediaType();
    pmt->SetType(&MEDIATYPE_Stream);
    pmt->SetSubtype(&MEDIASUBTYPE_NULL);
    return S_OK;
}

HRESULT 
MuxOutput::DecideBufferSize(IMemAllocator * pAlloc, ALLOCATOR_PROPERTIES * pprop)
{
    // we can break up large write into multiple buffers, so we are 
    // better off using a few small buffers
    pprop->cbBuffer = 4 * 1024;
    pprop->cBuffers = 20;
    pprop->cbAlign = 1;
    ALLOCATOR_PROPERTIES propActual;
    return pAlloc->SetProperties(pprop, &propActual);
}

HRESULT 
MuxOutput::CompleteConnect(IPin *pReceivePin)
{
    // make sure that this is the file writer, supporting
    // IStream, or we will not be able to write out the metadata
    // at stop time
    IStreamPtr pStream = pReceivePin;
    if (pStream == NULL)
    {
        return E_NOINTERFACE;
    }
    return CBaseOutputPin::CompleteConnect(pReceivePin);
}
    
void 
MuxOutput::Reset()
{
    CAutoLock lock(&m_csWrite);
    m_llBytes = 0;
    m_bUseIStream = false;
}

void
MuxOutput::UseIStream()
{
    CAutoLock lock(&m_csWrite);
    m_bUseIStream = true;
}

LONGLONG 
MuxOutput::Position()
{
    // start of this container in absolute byte position
    return 0;
}

LONGLONG
MuxOutput::Length()
{
    // length of this atom container (ie location of next atom)
    return m_llBytes;
}

HRESULT 
MuxOutput::Append(const BYTE* pBuffer, long cBytes)
{
    HRESULT hr = Replace(m_llBytes, pBuffer, cBytes);
    m_llBytes += cBytes;
    return hr;
}

HRESULT 
MuxOutput::Replace(LONGLONG pos, const BYTE* pBuffer, long cBytes)
{
    // all media content is written when the graph is running,
    // using IMemInputPin. On stop (during our stop, but after the
    // file writer has stopped), we switch to IStream for the metadata.
    // The in-memory index is updated after a successful call to this function, so
    // any data not written on completion of Stop will not be in the index.
    CAutoLock lock(&m_csWrite);

    HRESULT hr = S_OK;
    if (m_bUseIStream)
    {
        IStreamPtr pStream = GetConnected();
        if (pStream == NULL)
        {
            hr = E_NOINTERFACE;
        } else {
            LARGE_INTEGER liTo;
            liTo.QuadPart = pos;
            ULARGE_INTEGER uliUnused;
            hr = pStream->Seek(liTo, STREAM_SEEK_SET, &uliUnused);
            if (SUCCEEDED(hr))
            {
                ULONG cActual;
                hr = pStream->Write(pBuffer, cBytes, &cActual);
                if (SUCCEEDED(hr) && ((long)cActual != cBytes))
                {
                    hr = E_FAIL;
                }
            }
        }
    } else {
        // where the buffer boundaries lie is not important in this 
        // case, so break writes up into the buffers.
        while (cBytes && (hr == S_OK))
        {
            IMediaSamplePtr pSample;
            hr = GetDeliveryBuffer(&pSample, NULL, NULL, 0);
            if (SUCCEEDED(hr))
            {
                long cThis = min(pSample->GetSize(), cBytes);
                BYTE* pDest;
                pSample->GetPointer(&pDest);
                CopyMemory(pDest, pBuffer,  cThis);
                pSample->SetActualDataLength(cThis);
    
                // time stamps indicate file position in bytes
                LONGLONG tStart = pos;
                LONGLONG tEnd = pos + cThis;
                pSample->SetTime(&tStart, &tEnd);
                hr = Deliver(pSample);
                if (SUCCEEDED(hr))
                {
                    pBuffer += cThis;
                    cBytes -= cThis;
                    pos += cThis;
                }
            }
        }
    }
    return hr;
}
    
void 
MuxOutput::FillSpace()
{
    IStreamPtr pStream = GetConnected();
    if (pStream != NULL)
    {
        LARGE_INTEGER li0;
        li0.QuadPart = 0;
        ULARGE_INTEGER uliEnd;
        HRESULT hr = pStream->Seek(li0, STREAM_SEEK_END, &uliEnd);
        if (SUCCEEDED(hr))
        {
            if (uliEnd.QuadPart > (ULONGLONG) m_llBytes)
            {
                LONGLONG free = uliEnd.QuadPart - m_llBytes;
                if ((free < 0x7fffffff) && (free >= 8))
                {
                    // create a free chunk
                    BYTE b[8];
                    WriteLong(long(free), b);
                    WriteLong(DWORD('free'), b+4);
                    Append(b, 8);
                }
            }
        }
    }
}

// ---- seeking support ------------------------------------------------

SeekingAggregator::SeekingAggregator(CBaseFilter* pFilter, bool bSetTimeFormat)
: m_bSetTimeFormat(bSetTimeFormat)
{
    // collect all pins that support seeking.
    // if bSet is true, collect only those that
    // allow SetTimeFormat -- this will be one per splitter
    for (int i = 0; i < pFilter->GetPinCount(); i++)
    {
        CBasePin* pPin = pFilter->GetPin(i);
        PIN_DIRECTION pindir;
        pPin->QueryDirection(&pindir);
        if (pindir == PINDIR_INPUT)
        {
            IMediaSeekingPtr pSeek = pPin->GetConnected();
            if (pSeek != NULL)
            {
                HRESULT hr = S_OK;
                if (m_bSetTimeFormat)
                {
                    hr = pSeek->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
                }
                if (SUCCEEDED(hr))
                {
                    m_Pins.push_back(pSeek.Detach());
                }
            }
        }
    }
}

SeekingAggregator::~SeekingAggregator()
{
    for (iterator i = Begin(); i != End(); i++)
    {
        IMediaSeekingPtr pSeek = *i;
        // undo the SetTimeFormat call
        if (m_bSetTimeFormat)
        {
            pSeek->SetTimeFormat(&TIME_FORMAT_NONE);
        }
        pSeek->Release();
    }
}

STDMETHODIMP 
Mpeg4Mux::GetCurrentPosition(LONGLONG *pCurrent)
{
    if (m_pMovie == NULL)
    {
        // return previous total (after Stop)
        *pCurrent = m_tWritten;
    } else {
        // this is not passed upstream -- we report the 
        // position of the mux. Report the earliest write
        // time of any pin
        REFERENCE_TIME tCur = m_pMovie->CurrentPosition();
        *pCurrent = tCur;
    }

    return S_OK;
}

STDMETHODIMP 
Mpeg4Mux::GetCapabilities(DWORD * pCapabilities )
{
    // OR together all the pins' capabilities, together with our own
    DWORD caps = AM_SEEKING_CanGetCurrentPos;
    SeekingAggregator pins(this);
    for (SeekingAggregator::iterator i = pins.Begin(); i != pins.End(); i++)
    {
        IMediaSeekingPtr pSeek = *i;
        DWORD dwThis;
        HRESULT hr = pSeek->GetCapabilities(&dwThis);
        if (SUCCEEDED(hr))
        {
            caps |= dwThis;
        }
    }
    *pCapabilities = caps;
    return S_OK;
}

STDMETHODIMP 
Mpeg4Mux::CheckCapabilities(DWORD * pCapabilities )
{
    DWORD dwActual;
    GetCapabilities(&dwActual);
    if (*pCapabilities & (~dwActual)) {
        return S_FALSE;
    }
    return S_OK;
}

STDMETHODIMP 
Mpeg4Mux::IsFormatSupported(const GUID * pFormat)
{
    if (*pFormat == TIME_FORMAT_MEDIA_TIME)
    {
        return S_OK;
    }
    return S_FALSE;
}

STDMETHODIMP 
Mpeg4Mux::QueryPreferredFormat(GUID * pFormat)
{
    *pFormat = TIME_FORMAT_MEDIA_TIME;
    return S_OK;
}

STDMETHODIMP 
Mpeg4Mux::GetTimeFormat(GUID *pFormat)
{
    *pFormat = TIME_FORMAT_MEDIA_TIME;
    return S_OK;
}

STDMETHODIMP 
Mpeg4Mux::IsUsingTimeFormat(const GUID * pFormat)
{
    if (*pFormat == TIME_FORMAT_MEDIA_TIME)
    {
        return S_OK;
    }
    return S_FALSE;
}

STDMETHODIMP 
Mpeg4Mux::SetTimeFormat(const GUID * pFormat)
{
    if ((*pFormat == TIME_FORMAT_MEDIA_TIME) ||
        (*pFormat == TIME_FORMAT_NONE))
    {
        return S_OK;
    }
    return VFW_E_NO_TIME_FORMAT;
}

STDMETHODIMP 
Mpeg4Mux::GetDuration(LONGLONG *pDuration)
{
    // find the longest of all input durations
    SeekingAggregator pins(this);
    REFERENCE_TIME tMax = 0;
    for (SeekingAggregator::iterator i = pins.Begin(); i != pins.End(); i++)
    {
        IMediaSeekingPtr pSeek = *i;
        REFERENCE_TIME t;
        pSeek->GetDuration(&t);
        if (t > tMax)
        {
            tMax = t;
        }
    }
    *pDuration = tMax;
    return S_OK;
}

STDMETHODIMP 
Mpeg4Mux::GetStopPosition(LONGLONG *pStop)
{
    // return the first valid entry
    SeekingAggregator pins(this);
    if (pins.Begin() == pins.End())
    {
        return E_NOINTERFACE;
    }
    IMediaSeekingPtr pSeek = *pins.Begin();
    return pSeek->GetStopPosition(pStop);
}

STDMETHODIMP 
Mpeg4Mux::ConvertTimeFormat(LONGLONG * pTarget, const GUID * pTargetFormat,
                          LONGLONG    Source, const GUID * pSourceFormat )
{
    if (((pTargetFormat == 0) || (*pTargetFormat == TIME_FORMAT_MEDIA_TIME)) &&
        ((pSourceFormat == 0) || (*pSourceFormat == TIME_FORMAT_MEDIA_TIME)))
    {
        *pTarget = Source;
        return S_OK;
    }
    return VFW_E_NO_TIME_FORMAT;
}

STDMETHODIMP 
Mpeg4Mux::SetPositions(LONGLONG * pCurrent, DWORD dwCurrentFlags
        , LONGLONG * pStop, DWORD dwStopFlags )
{
    // must be passed to all valid inputs -- all must succeed
    SeekingAggregator pins(this, true);
    HRESULT hr = S_OK;
    for (SeekingAggregator::iterator i = pins.Begin(); i != pins.End(); i++)
    {
        IMediaSeekingPtr pSeek = *i;
        HRESULT hrThis = pSeek->SetPositions(pCurrent, dwCurrentFlags, pStop, dwStopFlags);
        if (FAILED(hrThis) && SUCCEEDED(hr))
        {
            hr = hrThis;
        }
    }
    return hr;
}

STDMETHODIMP 
Mpeg4Mux::GetPositions(LONGLONG * pCurrent,
                          LONGLONG * pStop )
{
    // return first valid input
    SeekingAggregator pins(this);
    if (pins.Begin() == pins.End())
    {
        return E_NOINTERFACE;
    }
    IMediaSeekingPtr pSeek = *pins.Begin();
    return pSeek->GetPositions(pCurrent, pStop);
}

STDMETHODIMP 
Mpeg4Mux::GetAvailable(LONGLONG * pEarliest, LONGLONG * pLatest )
{
    // the available section is the area for which any
    // data is available -- and here it is not very important whether
    // it is actually available
    *pEarliest = 0;
    return GetDuration(pLatest);
}

STDMETHODIMP 
Mpeg4Mux::SetRate(double dRate)
{
    // must be passed to all valid inputs -- all must succeed
    SeekingAggregator pins(this, true);
    HRESULT hr = S_OK;
    for (SeekingAggregator::iterator i = pins.Begin(); i != pins.End(); i++)
    {
        IMediaSeekingPtr pSeek = *i;
        HRESULT hrThis = pSeek->SetRate(dRate);
        if (FAILED(hrThis) && SUCCEEDED(hr))
        {
            hr = hrThis;
        }
    }
    return hr;
}

STDMETHODIMP 
Mpeg4Mux::GetRate(double * pdRate)
{
    // return first valid input
    SeekingAggregator pins(this);
    if (pins.Begin() == pins.End())
    {
        return E_NOINTERFACE;
    }
    IMediaSeekingPtr pSeek = *pins.Begin();
    return pSeek->GetRate(pdRate);
}

STDMETHODIMP 
Mpeg4Mux::GetPreroll(LONGLONG * pllPreroll)
{
    // preroll time needed is the longest of any
    SeekingAggregator pins(this);
    REFERENCE_TIME tMax = 0;
    for (SeekingAggregator::iterator i = pins.Begin(); i != pins.End(); i++)
    {
        IMediaSeekingPtr pSeek = *i;
        REFERENCE_TIME t;
        pSeek->GetPreroll(&t);
        if (t > tMax)
        {
            tMax = t;
        }
    }
    *pllPreroll = tMax;
    return S_OK;
}

